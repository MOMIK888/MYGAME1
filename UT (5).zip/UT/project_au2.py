import pygame
import random
import math
import copy
class Player:
    def __init__(self, screen_width, screen_height,hp,dmg,x,y,restr,dmgamp):
        self.__width = screen_width // 52
        self.__height = screen_height // 30
        self.hp=hp
        self.sound1 = pygame.mixer.Sound("dustdust/undertale-damage-taken.mp3")
        self.allow=restr
        self.countdown = 0
        self.dmgamp=dmgamp
        self.__dmg=dmg
        self.__sprite = pygame.transform.smoothscale(
            pygame.image.load("dustdust/s5n7r4l3fo7x.png").convert_alpha(),
            (self.__width//1.2, self.__height//1.2)
        )
        self.__sprite_rect= self.__sprite.get_rect()
        self.collision = self.__sprite_rect
        self.__x = x
        self.j=pygame.font.Font("dustdust/impact.ttf", 24)
        self.music=True
        self.__y = y
        self.Gameover=0
        self.cnt=0
        self.R=False
        self.Stamina=30
        self.__horizontal_move_flag = self.__vertical_move_flag = 0
        self.__speed = 5.2
        self.__direction = {pygame.K_w: False,pygame.K_a: False,pygame.K_s: False,pygame.K_d: False,pygame.K_SPACE: False}
        self.__sprite_rect.x=screen_width//2
        self.__sprite_rect.y= screen_height//2
        self.invisibility=0
        self.boundaries_x= [0,screen_width - self.__width]
        self.boundaries_y = [0, screen_height - self.__height]
        self.get_x=self.__sprite_rect.x
    def get_direction_keys(self):
        return self.__direction.keys()
    def check_event(self, event):
        if event.type == pygame.KEYDOWN:
            self.__direction[event.key]=True
        elif event.type == pygame.KEYUP:
            self.__direction[event.key] = False
    def change_pos(self,x,y):
        self.__sprite_rect.x=x
        self.__sprite_rect.y=y
    def get_rest(self,all):
        self.allow=all
    def get_damage(self,damage):
        if self.invisibility<1:
            self.hp-=(damage+self.dmgamp)
            self.invisibility=48
            self.sound1.play()
    def check_logic(self):
        if self.__sprite_rect.x < self.boundaries_x[0]:
            self.__sprite_rect.x = self.boundaries_x[0]
        elif self.__sprite_rect.x > self.boundaries_x[1]:
            self.__sprite_rect.x = self.boundaries_x[1]
        if self.__sprite_rect.y < self.boundaries_y[0]:
            self.__sprite_rect.y = self.boundaries_y[0]
        elif self.__sprite_rect.y > self.boundaries_y[1]:
            self.__sprite_rect.y = self.boundaries_y[1]


    def move(self):
        if self.allow==True:
            self.__sprite_rect.x+=self.__speed*(self.__direction[pygame.K_d]-self.__direction[pygame.K_a])
            self.__sprite_rect.y+=self.__speed*(self.__direction[pygame.K_s] - self.__direction[pygame.K_w])
            self.collision = self.__sprite_rect
        if self.invisibility>0:
            self.invisibility-=1
    def draw(self, screen,j=0,k=0):
        self.get_x = self.__sprite_rect.x
        screen.blit(self.__sprite, (self.__sprite_rect.x, self.__sprite_rect.y))
        k = str(self.hp)+'/20'
        k = self.j.render(k, True,
                     (255, 255, 255))
        screen.blit(k, (810, 765))
        k=self.j.render('HP', True,
                 (255, 255, 255))
        screen.blit(k, (650, 765))
        pygame.draw.rect(screen, [255, 0,0], pygame.Rect(700, 770, 100, 25))
        pygame.draw.rect(screen, [255,255,0], pygame.Rect(700, 770, self.hp*5, 25))
    def change_sprite(self,sprite):
        self.__sprite = pygame.transform.smoothscale(
            sprite.convert_alpha(),
            (self.__width, self.__height)
        )
        self.__sprite_rect = self.__sprite.get_rect()
class Attack_vert:
    def __init__(self,player,color,direction,speed,pos,pos2,len):
        self.player=player
        self.colour = color
        if self.colour=='WHITE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51.png").convert_alpha(),
                (60, len))
        elif self.colour=='BLUE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51 (1).png").convert_alpha(),
                (60, len))
        else:
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51 (2).png").convert_alpha(),
                (60, len))
        self.bone_spr= pygame.transform.rotate(self.bone_spr, 90)
        self.bone_rect= self.bone_spr.get_rect()
        self.bone_rect.x=pos2
        self.bone_rect.y=pos
        self.dir=direction
        self.speed=speed
        self.pos_get=self.player.get_x
        self.lengh=len
    def atc(self,player):
        if player.collision.x<self.bone_rect.centerx+self.lengh//2 and player.collision.x>self.bone_rect.centerx-self.lengh//2:
            if player.collision.y<self.bone_rect.centery+15 and player.collision.y>self.bone_rect.centery-15:
                if self.colour=='BLUE':
                    if self.pos_get != self.player.get_x:
                        player.get_damage(2)
                elif self.colour == 'YELLOW':
                    if self.pos_get == self.player.get_x:
                            player.get_damage(2)
                else:
                    player.get_damage(2)
        self.bone_rect.y+=self.speed*self.dir
        self.pos_get = self.player.get_x
    def draw(self,screen):
        screen.blit(self.bone_spr,self.bone_rect)
class Attack_horizontal:
    def __init__(self,player,color,direction,speed,pos,pos2,len):
        self.player=player
        self.colour = color
        self.bone_spr=''
        self.dir=direction
        self.pos2=pos2
        self.pos=pos
        self.speed=speed
        self.pos_get=self.player.get_x
        self.lengh=len
        self.frame_count=0
    def atc(self,player):
        self.frame_count+=1
        if self.frame_count%3==0:
            if player.collision.x<self.bone_rect.x+15 and player.collision.x>self.bone_rect.x-15:
                if player.collision.y<self.bone_rect.centery+self.lengh//2 and player.collision.y>self.bone_rect.centery-self.lengh//2:
                    if self.colour=='BLUE':
                        if self.pos_get != self.player.get_x:
                            player.get_damage(2)
                    elif self.colour == 'YELLOW':
                        if self.pos_get == self.player.get_x:
                            player.get_damage(2)
                    else:
                        player.get_damage(2)
        self.bone_rect.x+=self.speed*self.dir
        self.pos_get = self.player.get_x
    def pre_render(self):
        if self.colour=='WHITE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51.png").convert_alpha(),
                (60, self.lengh))
        elif self.colour=='BLUE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51 (1).png").convert_alpha(),
                (60, self.lengh))
        else:
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51 (2).png").convert_alpha(),
                (60, self.lengh))
        self.bone_rect= self.bone_spr.get_rect()
        self.bone_rect.x = self.pos2
        self.bone_rect.y = self.pos
    def draw(self,screen):
        screen.blit(self.bone_spr,self.bone_rect)
class Gaster_blaster:
    def __init__(self, player, color, direction, speed, pos,pos2):
        self.player = player
        self.dir = direction
        self.colour = color
        self.i=0
        if self.colour=='BLUE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (2).png").convert_alpha(),
                (165, 220))
            self.battle_spr=pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (5).png").convert_alpha(),
                (110, 145))
        elif self.colour=='ORANGE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (1).png").convert_alpha(),
                (110, 145))
            self.battle_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (6).png").convert_alpha(),
                (110, 145))
        else:
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (3).png").convert_alpha(),
                (60, 160))
            self.battle_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (4).png").convert_alpha(),
                (60, 160))
        self.bone_rect = self.bone_spr.get_rect()
        self.bone_rect.x = pos2-speed*100
        self.bone_rect.y = pos
        self.speed = speed

    def atc(self, player):
        if 100<self.i<270:
            self.bone_spr=self.battle_spr
            if player.collision.x < self.bone_rect.x + 15 and player.collision.x > self.bone_rect.x - 15:
                if player.collision.y < self.bone_rect.centery + 80 and player.collision.y > self.bone_rect.centery - 80:
                    player.get_damage(5)
        elif self.i>270:
            if self.bone_rect.x>540:
                self.bone_rect.x+=100
            else:
                self.bone_rect.x -= 100

    def draw(self, screen):
        screen.blit(self.bone_spr, self.bone_rect)
        self.i += self.speed
        if self.i<100:
            self.bone_rect.x+=100/self.speed
        if 100 < self.i < 270:
            self.randomiser=random.randint(-10,10)
            pygame.draw.rect(screen, [140, 140, 140],
                             pygame.Rect(self.bone_rect.x + (90-50-self.randomiser)//2, self.bone_rect.y + 120, 70-self.randomiser, 500))
            pygame.draw.rect(screen, [200, 200, 200],
                             pygame.Rect(self.bone_rect.x + (90-60-self.randomiser)//2, self.bone_rect.y + 120, 60-self.randomiser, 500))
            pygame.draw.rect(screen, [255, 255, 255],
                             pygame.Rect(self.bone_rect.x +  (90-50-self.randomiser)//2, self.bone_rect.y + 120, 50-self.randomiser, 500))
class Fight:
    def __init__(self,screen_width, screen_height,player):
        self.width=screen_width
        self.spare_cnt=0
        self.height=screen_height
        self.player=player
        self.hp=100
        self.w=252
        self.ans=True
        self.h = 408
        self.countdown = 0
        self.message=''
        self.cntdown=0
        self.g = 0
        self.r=False
        self.attacks=[]
        self.boots=[self.width//3,40]
        self.hoodie=[self.width//3-105,-100]
        self.head=[self.width//3,30]
        self.shorts=[self.width//3-155,-215]
        self.legs=[self.width//3,40]
        self.font = pygame.font.Font("dustdust/impact.ttf", 24)
        self.status=False
        self.talk = self.font.render('', True,
                             (255, 255, 255))
        self.k=10
        self.j=0
        self.head_coord=[10,0]
        self.talk_coords=[0,0]
        self.frame_cnt=0
        self.cup=[self.width//3-105,-200]
        self.breathing_spr=''
        self.breathing_cnt=0
        self.button_sprites2 = [
            pygame.transform.smoothscale(pygame.image.load("dustdust/fightcl.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Actcl.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/ITEMCL.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Mercycl.png").convert_alpha(), (138, 50))]
        self.button_sprites=[pygame.transform.smoothscale(pygame.image.load("dustdust/fight.png").convert_alpha(),(138,50)),
                             pygame.transform.smoothscale(pygame.image.load("dustdust/Act.png").convert_alpha(),(138,50)),
                             pygame.transform.smoothscale(pygame.image.load("dustdust/ITEM.png").convert_alpha(),(138,50)),
                             pygame.transform.smoothscale(pygame.image.load("dustdust/Mercy.png").convert_alpha(),(138,50))]
        self.button_spritesr = [
            pygame.transform.smoothscale(pygame.image.load("dustdust/fight.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Act.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/ITEM.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Mercy.png").convert_alpha(), (138, 50))]
        self.coords_buttons = [[500-60,800],[610,800],[810-30,800],[1010-60,800]]
        self.animation_count=0
        self.breathing_cooldown=0
        self.coords=[self.boots, self.hoodie,self.head,self.shorts,self.legs,self.cup]
        self.__sprites = [pygame.transform.smoothscale(pygame.image.load("dustdust/boots.png").convert_alpha(),(self.w,int(self.h ))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/hoodie (1) (1) (1).png").convert_alpha(),(self.w*1.8,int(self.h*1.7))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/head.png").convert_alpha(),(self.w,int(self.h ))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/shorts.png").convert_alpha(),(self.w*2.2,int(self.h*2.2))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/legs.png").convert_alpha(),(self.w,int(self.h ))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/hoodie (1) (1) (2).png").convert_alpha(),(self.w*1.8,int(self.h*1.7))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/steam.png").convert_alpha(),(self.w*1.8,int(self.h*2))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/steam (1).png").convert_alpha(),(self.w*1.8,int(self.h*2))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/steam (2).png").convert_alpha(),(self.w*1.8,int(self.h*2))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/breathing.png").convert_alpha(),
                                                       (self.w * 2.7, int(self.h * 1.7))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/breathing (1).png").convert_alpha(),
                                                       (self.w * 2.7, int(self.h * 1.7))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/breathing (2).png").convert_alpha(),
                                                       (self.w * 2.7, int(self.h * 1.7)))
                          ]
        for i in range(6,9):
            self.__sprites[i].set_alpha(100)
        for i in range(9,12):
            self.__sprites[i].set_alpha(255-(i-7)*50)
        self.steam_spr=self.__sprites[6]
    def fight(self,list1,list2):
        self.player.boundaries_x=list1
        self.player.boundaries_y = list2

    def rot(self,image, angle):
        return image+angle
    def anim(self):
        self.frame_cnt += 1
        if self.frame_cnt%3==0:
            if self.k>0:
                self.coords[1][1]+=(11-self.k)/10
                self.coords[2][1] += (12 - self.k) / 10
                self.coords[3][1] += (12 - self.k) / 10
                self.coords[4][1] += (12 - self.k) / 12
                self.k -= 1
            elif self.j>0:
                self.coords[1][1]-=(11-self.j)/10
                self.coords[2][1] -= (12 - self.j) / 10
                self.coords[3][1] -= (12 - self.j) / 10
                self.coords[4][1] -= (12 - self.j) / 12
                self.j-=1
            if self.k<1 and self.j<1 and self.frame_cnt%9==0:
                if self.coords[2][1]<30:
                    self.k=10
                else:
                    self.j=10
        if self.frame_cnt%3==0:
            self.animation_count+=1
            self.animation_count=self.animation_count%12
            self.steam_spr = self.__sprites[6+self.animation_count//4]
        if 7<self.breathing_cooldown<16:
            self.breathing_spr=self.__sprites[11]
        elif self.breathing_cooldown<8 and self.breathing_cooldown>0:
            self.breathing_spr.set_alpha(0)
        elif self.frame_cnt%3==0 and self.breathing_cooldown<1:
            self.breathing_cnt+=1
            self.breathing_cnt=self.breathing_cnt%12
            self.breathing_spr = self.__sprites[9+self.breathing_cnt//4]
            if 9+self.breathing_cnt//4==11:
                self.breathing_cooldown=15
        if self.breathing_cooldown>0:
            self.breathing_cooldown-=1
    def draw(self,screen):
        pygame.draw.rect(screen, (0, 0, 0),
                         (500, self.height // 2 // 1.2,self.width//3-150, 310))
        pygame.draw.rect(screen, (255, 255, 255),
                         (500, self.height//2//1.2, self.width//3-150,310 ), 3)
        self.count=0
        self.coords[5][1]=self.coords[1][1]-60
        screen.blit(self.__sprites[4],self.coords[4])
        screen.blit(self.__sprites[3], self.coords[3])
        screen.blit(self.__sprites[1], self.coords[1])
        screen.blit(self.__sprites[5], self.coords[1])
        screen.blit(self.steam_spr, self.coords[5])
        screen.blit(self.__sprites[2], self.coords[2])
        screen.blit(self.__sprites[0], self.coords[0])
        if self.breathing_spr!='':
            screen.blit(self.breathing_spr,[self.coords[1][0]-120,self.coords[1][1]+25])
        for i in range(len(self.button_sprites)):
            screen.blit(self.button_sprites[i], self.coords_buttons[i])

        self.finish_game(screen,self.player)
        self.frame_cnt += 1
        self.win(self.hp, screen)
        self.spare(self.status,screen)
        screen.blit(self.talk, (self.talk_coords))
        if self.cntdown>0:
            pygame.draw.rect(screen, [0, 0, 0], pygame.Rect(self.coords[2][0]-230-110,self.coords[2][1]+110, 300, 100))
            pygame.draw.rect(screen, [255, 255, 255], pygame.Rect(self.coords[2][0]-230-110,self.coords[2][1]+110, 300, 100),3)
            screen.blit(self.message,[self.coords[2][0]-220-110,self.coords[2][1]+120])
            self.cntdown-=1
        if self.player.hp>0 and self.hp>0:
            self.countdown -=1
            if self.countdown<1:
                self.talk = self.font.render('', True,
                                     (255, 255, 255))
    def finish_game(self,screen,player):
        if player.hp<1:
            j = pygame.font.Font(None, 24)
            self.talk = j.render('ВЫ ПРОИГРАЛИ', True,
                                 (255, 255, 255))
            self.talk_coords = [550,500]
            self.dialogue("УРА, Я ПОБЕДИЛ!")
            pygame.mixer.music.stop()
    def spare(self,status, screen):
        if status==True and self.spare_cnt==0:
            j = pygame.font.Font(None, 24)
            self.talk = j.render('ВЫ ЗАКОНЧИЛИ БОЙ МИРНО', True,
                                 (255, 255, 255))
            self.talk_coords = [550,500]
            self.dialogue("Спасибо")
            pygame.mixer.music.stop()
        elif status==True:
            self.dialogue("Нет, бой еще не окончен")
            self.status=False
    def choosing_button(self,event,bl,atclist):
        if self.ans==False:
            self.player.change_pos(self.coords_buttons[self.g][0]+5, self.coords_buttons[self.g][1]+10)
            self.fight([400,950],[700,900])
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_a and self.g>0:
                    self.g-=1
                elif event.key==pygame.K_d and self.g<3:
                    self.g+=1
                if self.g!=-1:
                    self.button_sprites[self.g]=self.button_sprites2[self.g]
                for i in range(4):
                    if i!=self.g:
                        self.button_sprites[i]=self.button_spritesr[i]
            if event.type==pygame.MOUSEBUTTONDOWN:
                if self.g==0:
                    self.hp-=25
                    j = pygame.font.Font(None, 24)
                    text=str(self.hp)+'/100'
                    self.talk = j.render(text, True,
                                         (255, 255, 255))
                    self.talk_coords = [550, 500]
                elif self.g==1:
                    j = pygame.font.Font(None, 24)
                    self.talk = j.render('Разговоры не помогут', True,
                                 (255, 255, 255))
                    self.talk_coords = [550, 500]
                elif self.g==2:
                    self.player.get_damage(-10)
                else:
                    self.status=True
                    self.talk_coords=[550,500]
                self.button_sprites[self.g] = self.button_spritesr[self.g]
                self.ans=True
                self.countdown=30
        else:
            self.fight([500, self.width // 2], [self.height // 2 - 90, self.height // 1.5])
    def dialogue(self,text):
        lll=pygame.font.Font(None, 24)
        self.message=lll.render(text, True,
                                (255,255,255))
        if text!="dd":
            self.cntdown=90
        else:
            self.cntdown=0
    def win(self,hp,screen):
        if hp<1:
            for i in self.coords:
                i[0]+=10
            j = pygame.font.Font(None, 48)
            self.talk = j.render('ВЫ ПОБЕДИЛИ', True,
                                 (255, 255, 255))
            self.talk_coords = [670,450]
            gg=pygame.font.Font(None, 24)
            self.dialogue("Я ухожу")
            pygame.mixer.music.stop()
class Welcome_screen:
    def __init__(self,w,h):
        self.width=w
        self.alpha=0
        self.choice=pygame.transform.smoothscale(pygame.image.load("dustdust/s5n7r4l3fo7x.png").convert_alpha(),(20,20))
        self.alpha1=0
        self.finaldiff=0
        self.height=h
        self.settings=False
        self.frame_cnt=0
        self.wait=False
        self.menu=pygame.transform.smoothscale(pygame.image.load("dustdust/menu.png").convert_alpha(),(168*2,272*2))
        self.diff=self.sprites=pygame.transform.smoothscale(pygame.image.load("dustdust/diificulty.png").convert_alpha(),(255*5,138*5))
        self.gs=False
        self.difficulty=[True,False,False]
        self.ans=[False,False]
        self.f=['','']
        self.k=5
        pygame.mixer.music.load("dustdust/videoplayback.mp3")
        self.j=0
        self.kk=0
        self.stand=[False,False,False]
        self.counting=0
        self.coords=[[750,250],[250,500],[-100,-500]]
        self.sprites=[pygame.transform.smoothscale(pygame.image.load("dustdust/start.png").convert_alpha(),(255*2,138*2)),
                      pygame.transform.smoothscale(pygame.image.load("dustdust/settings.png").convert_alpha(),(255*2,138*2))]
        self.animation_count=0
        for i in self.sprites:
            i.set_alpha(200)
    def waiting(self):
        self.counting+=1
        if self.counting>10 and self.wait==False:
            pygame.mixer.music.play(-1)
            self.wait=True
    def anim(self):
        self.frame_cnt += 1
        if self.settings:
            self.kk+=1
            if self.coords[2][1]+10<90:
                self.coords[2][1]+=self.kk
        elif self.coords[2][1]>-500:
            self.coords[2][1] -= 10
        if self.frame_cnt%3==0:
            if self.k>0:
                self.coords[0][1]+=(11-self.k)/8
                self.coords[1][1] -= (11 - self.k) / 8
                self.coords[2][1] -= (10 - self.k) / 10
                self.k -= 1
            elif self.j>0:
                self.coords[0][1]-=(11-self.j)/8
                self.coords[1][1] += (11 - self.j) / 8
                self.coords[2][1] += (10 - self.j) / 10
                self.j-=1
            if self.k<1 and self.j<1:
                if self.coords[0][1]<250:
                    self.k=10
                else:
                    self.j=10
    def draw(self,screen):
        self.waiting()
        self.anim()
        self.returning()
        if self.f!='':
            screen.fill([0,0,0])
            screen.blit(self.sprites[0], self.f[0])
            screen.blit(self.sprites[1], self.f[1])
            screen.blit(self.diff,self.coords[2])
            screen.blit(self.menu,[600,530])
            for i in range(3):
                if self.difficulty[i]==True:
                    screen.blit(self.choice,[self.coords[2][0]+480+120*i,self.coords[2][1]+370])
        if self.ans[0]==True:
                self.sprites[0].set_alpha(self.alpha+200)
                if self.alpha+3<255:
                    self.alpha+=3
        else:
            self.sprites[0].set_alpha(self.alpha+200)
            if self.alpha-5>0:
                self.alpha-=5
        if self.ans[1]==True:
                self.sprites[1].set_alpha(self.alpha1+200)
                if self.alpha1+3<255:
                    self.alpha1+=3
        else:
            self.sprites[1].set_alpha(self.alpha1+200)
            if self.alpha1-5>0:
                self.alpha1-=5

    def returning(self):
        for i in range(len(self.sprites)):
            self.f[i]=self.sprites[i]
            self.f[i]=self.f[i].get_rect()
            self.f[i].x=self.coords[i][0]
            self.f[i].y = self.coords[i][1]
            mouse=pygame.mouse.get_pos()
            if mouse[0] > self.f[i].topleft[0]:
                if mouse[1] > self.f[i].topleft[1]:
                    if mouse[0] < self.f[i].bottomright[0]:
                        if mouse[1] < self.f[i].bottomright[1]:
                            self.ans[i]=True
                        else:
                            self.ans[i]=False
                    else:
                        self.ans[i]=False
                else:
                    self.ans[i]=False
            else:
                self.ans[i]=False
            if mouse[1]>self.coords[2][1]+320 and mouse[1]<self.coords[2][1]+370:
                if mouse[0]<self.coords[2][0]+560 and mouse[0]>self.coords[2][0]+460:
                    self.difficulty[0]=True
                    self.difficulty[1] = False
                    self.difficulty[2] = False
            if mouse[1]>self.coords[2][1]+320 and mouse[1]<self.coords[2][1]+370:
                if mouse[0]<self.coords[2][0]+670 and mouse[0]>self.coords[2][0]+570:
                    self.difficulty[0] = False
                    self.difficulty[1]=True
                    self.difficulty[2] = False
            if mouse[1]>self.coords[2][1]+320 and mouse[1]<self.coords[2][1]+370:
                if mouse[0]<self.coords[2][0]+910 and mouse[0]>self.coords[2][0]+680:
                    self.difficulty[0] = False
                    self.difficulty[1] = False
                    self.difficulty[2]=True
    def G_S(self,event):
        self.finaldiff=self.difficulty.index(True)
        if event.type==pygame.MOUSEBUTTONDOWN and self.ans[0]==True:
            self.gs=True
            pygame.mixer.music.stop()
        if event.type==pygame.MOUSEBUTTONDOWN and self.ans[1]==True:
            self.settings=True
class Game:
    def __init__(self, width=1920, height=1080, fps=60,hp=20,dmg1=10,dmg=10):
        pygame.init()
        self.__cnt=1
        self.__STATUS = [1,1]
        self.__hp= hp
        self.__dmg1=dmg1
        self.__dmg=dmg
        self.__width = width
        self.__height = height
        self.__K=[]
        self.__width2 = width
        self.__height2 = height
        self.__hp2 = hp
        self.__screen = pygame.display.set_mode((self.__width, self.__height),pygame.FULLSCREEN)
        self.__x = 800 // 2 - 60
        self.__y = 600 // 2 - 60
        self.t = random.randint(1, 5)
        self.actions=True
        self.__fps = fps
        self.__clock = pygame.time.Clock()
        self.__game_end = False
        self.__s=[]
        self.welcome = Welcome_screen(self.__width, self.__height)
        self.damageamp = self.welcome.finaldiff
        self.__player = Player(self.__width, self.__height,self.__hp,self.__dmg,self.__x,self.__y,self.actions,self.damageamp)
        self.__fight=Fight(self.__width, self.__height,self.__player)
        self.actions =self.__fight.ans
        self.attacks_list=[[],[],[]]
        self.attacks()
        for llll in self.attacks_list:
            for i in llll:
                if i!='':
                    print(str(type(i)))
                    if str(type(i))!="<class 'list'>" and str(type(i))!="<class 'bool'>" and str(type(i))!="<class 'str'>" and str(type(i))!="<class '__main__.Attack_vert'>":
                        i.pre_render()
                    elif str(type(i))!="<class 'str'>" and str(type(i))!="<class 'bool'>" and str(type(i))!="<class '__main__.Attack_vert'>":
                        for j in i:
                            j.pre_render()
        self.i=0
        self.music=True
        self.frame_count=0
        self.g=False
        self.__bg_sprite = pygame.transform.smoothscale(
            pygame.image.load("dustdust/bc.png").convert(),
            (1600, 890))
        self.activat=False
        self.g=self.welcome.gs
    def __del__(self):
        pygame.quit()
    def run(self):
        while not self.__game_end:
            self.__check_events()
            self.__check_logic()
            self.__move_objects()
            self.__draw()
            self.__flip()
            self.__clock.tick(self.__fps)
    def __check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.__game_end = True

            self.__player.check_event(event)
            self.__fight.choosing_button(event,self.actions,self.attacks_list)
            if self.g!=True:
                self.welcome.G_S(event)
    def __check_logic(self):
        self.__player.check_logic()
    def music_pl(self):
        if self.music:
            pygame.mixer.music.stop()
            pygame.mixer.music.load("dustdust/videoplayback (1).mp3")
            pygame.mixer.music.play(-1)
            self.music=False
    def __move_objects(self):
        self.__player.move()
        self.__player.get_rest(self.actions)
    def __draw(self):
        self.__fight.spare_cnt=len(self.attacks_list)
        self.actions = self.__fight.ans
        self.__screen.blit(self.__bg_sprite, (0, 0))
        if self.g==True:
            self.music_pl()
            self.__fight.anim()
            self.__fight.draw(self.__screen)
            if self.actions and self.__player.hp>0 and self.__fight.hp>0:
                self.battle()
            if self.__player.hp > 0 and self.__fight.hp > 0:
                self.__player.draw(self.__screen)
        else:
            self.welcome.draw(self.__screen)
            self.g = self.welcome.gs
            self.__player.dmgamp=self.welcome.finaldiff
    def __flip(self):
        pygame.display.flip()
    def battle(self):
        if len(self.attacks_list)>0:
            if self.i<len(self.attacks_list[0])*30:
                self.i+=1
            self.frame_count=self.i//30
            for i in self.attacks_list[0][0:self.frame_count]:
                if i!='':
                    if str(type(i))!="<class 'list'>" and str(type(i))!="<class 'bool'>" and str(type(i))!="<class 'str'>":
                        i.draw(self.__screen)
                        i.atc(self.__player)
                    elif str(type(i))=="<class 'bool'>":
                        if i!=True:
                            self.actions=False
                            self.__fight.ans=False
                        self.i=0
                        self.attacks_list.pop(0)
                        self.frame_count=0
                    elif str(type(i))!="<class 'str'>":
                        for j in i:
                            j.draw(self.__screen)
                            j.atc(self.__player)
                    else:
                        self.__fight.dialogue(i)
    def attacks(self,b=[]):
        b=[]
        b.append(Attack_horizontal(self.__player,'WHITE',1,4,450,400,160))
        b.append(Attack_horizontal(self.__player,'WHITE',-1,4,600,1200,160))
        self.attacks_list[0].append("Привет")
        for i in range(5):
            self.attacks_list[0].append('')
        self.attacks_list[0].append("предметы восстанавливают 10 hp")
        for i in range(5):
            self.attacks_list[0].append('')
        self.attacks_list[0].append("атака наносит 25 dmg")
        for i in range(5):
            self.attacks_list[0].append('')
        self.attacks_list[0].append("Пощада заканчивает бой")
        for i in range(5):
            self.attacks_list[0].append('')
        self.attacks_list[0].append("dd")
        self.attacks_list[0].append(True)
        for i in range(10):
            self.attacks_list[1].append([Attack_horizontal(self.__player,'WHITE',1,5,450,400,160),Attack_horizontal(self.__player,'WHITE',-1,5,600,1300,160)])
        for i in range(3):
            self.attacks_list[1].append([Attack_horizontal(self.__player,'BLUE',-1,9,350,1200,240),Attack_horizontal(self.__player,'BLUE',-1,10,600,1300,500)])
            self.attacks_list[1].append([Attack_horizontal(self.__player, 'BLUE', -1, 6, 500, 1200,160),
                                      Attack_horizontal(self.__player, 'YELLOW', -1, 6, 600, 1300,190)])
            self.attacks_list[1].append([Attack_horizontal(self.__player, 'BLUE', -1, 9, 450, 1200,200),
                                      Attack_horizontal(self.__player, 'BLUE', -1, 11, 700, 1300,170),Attack_horizontal(self.__player, 'WHITE', -1, 5, 600, 1300, 160)])
            self.attacks_list[1].append([Attack_horizontal(self.__player, 'YELLOW', -1, 6, 450, 1200, 200),
                                     Attack_horizontal(self.__player, 'BLUE', -1, 3, 400, 1300, 170),Attack_horizontal(self.__player, 'WHITE', 1, 5, 450, 400, 160)])
        self.attacks_list[1].append(False)
        for i in range(3):
            self.attacks_list[2].append([Attack_horizontal(self.__player, 'BLUE', 1, 10, 400, 400, 400),
                                          Attack_horizontal(self.__player, 'YELLOW', -1, 10, 400, 1300, 400)])
            self.attacks_list[2].append('')
        self.attacks_list[2].append(False)
        self.attacks_list.append([])
        for i in range(10):
            self.attacks_list[3].append(Attack_horizontal(self.__player, 'WHITE', 1, 4, 450, 400, 240))
            self.attacks_list[3].append([Attack_horizontal(self.__player, 'BLUE', 1, 10, 680, 300, 80),
                                         Attack_horizontal(self.__player, 'YELLOW', 1, 10, 680, 400, 80)])
        self.attacks_list[3].append(False)
        self.attacks_list.append([])
        for i in range(5):
            self.attacks_list[4].append(Attack_vert(self.__player, 'WHITE', 1, 5, 100, 475, 270))
            self.attacks_list[4].append("")
            self.attacks_list[4].append(Attack_vert(self.__player, 'WHITE', -1, 5, 900, 715, 270))
            self.attacks_list[4].append([Attack_horizontal(self.__player, 'WHITE', 1, 5, 450, 400, 160),
                                         Attack_horizontal(self.__player, 'WHITE', -1, 5, 600, 1300, 160)])
        self.attacks_list[4].append("Я устал")
        self.attacks_list[4].append(False)



def main():
    game = Game()
    game.run()


if __name__ == "__main__":
    main()
