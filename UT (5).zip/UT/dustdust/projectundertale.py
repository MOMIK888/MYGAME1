import pygame
import random
import math
import copy
class Player:
    def __init__(self, screen_width, screen_height,hp,dmg,x,y):
        self.__width = screen_width // 52
        self.__height = screen_height // 30
        self.hp=hp
        self.countdown = 0
        self.__dmg=dmg
        self.__sprite = pygame.transform.smoothscale(
            pygame.image.load("dustdust/s5n7r4l3fo7x.png").convert_alpha(),
            (self.__width//1.2, self.__height//1.2)
        )
        self.__sprite_rect= self.__sprite.get_rect()
        self.collision = self.__sprite_rect
        self.__x = x
        self.__y = y
        self.Gameover=0
        self.cnt=0
        self.R=False
        self.Stamina=30
        self.__horizontal_move_flag = self.__vertical_move_flag = 0
        self.__speed = 5.2
        self.__direction = {pygame.K_w: False,pygame.K_a: False,pygame.K_s: False,pygame.K_d: False,pygame.K_SPACE: False}
        self.__sprite_rect.x=screen_width//2
        self.__sprite_rect.y= screen_height//2
        self.invisibility=0
        self.boundaries_x= [0,screen_width - self.__width]
        self.boundaries_y = [0, screen_height - self.__height]
        self.get_x=self.__sprite_rect.x
    def get_direction_keys(self):
        return self.__direction.keys()
    def check_event(self, event):
        if event.type == pygame.KEYDOWN:
            self.__direction[event.key]=True
        elif event.type == pygame.KEYUP:
            self.__direction[event.key] = False
    def change_pos(self,x,y):
        self.__sprite_rect.x=x
        self.__sprite_rect.y=y
    def get_damage(self,damage):
        if self.invisibility<1:
            self.hp-=damage
            self.invisibility=48
    def check_logic(self):
        if self.__sprite_rect.x < self.boundaries_x[0]:
            self.__sprite_rect.x = self.boundaries_x[0]
        elif self.__sprite_rect.x > self.boundaries_x[1]:
            self.__sprite_rect.x = self.boundaries_x[1]
        if self.__sprite_rect.y < self.boundaries_y[0]:
            self.__sprite_rect.y = self.boundaries_y[0]
        elif self.__sprite_rect.y > self.boundaries_y[1]:
            self.__sprite_rect.y = self.boundaries_y[1]


    def move(self):
        self.__sprite_rect.x+=self.__speed*(self.__direction[pygame.K_d]-self.__direction[pygame.K_a])
        self.__sprite_rect.y+=self.__speed*(self.__direction[pygame.K_s] - self.__direction[pygame.K_w])
        self.collision = self.__sprite_rect
        if self.invisibility>0:
            self.invisibility-=1
    def draw(self, screen,j=0,k=0):
        self.get_x = self.__sprite_rect.x
        screen.blit(self.__sprite, (self.__sprite_rect.x, self.__sprite_rect.y))
        j=pygame.font.Font("dustdust/impact.ttf", 24)
        k = str(self.hp)+'/20'
        k = j.render(k, True,
                     (255, 255, 255))
        screen.blit(k, (810, 765))
        k=j.render('HP', True,
                 (255, 255, 255))
        screen.blit(k, (650, 765))
        pygame.draw.rect(screen, [255, 0,0], pygame.Rect(700, 770, 100, 25))
        pygame.draw.rect(screen, [255,255,0], pygame.Rect(700, 770, self.hp*5, 25))
    def change_sprite(self,sprite):
        self.__sprite = pygame.transform.smoothscale(
            sprite.convert_alpha(),
            (self.__width, self.__height)
        )
        self.__sprite_rect = self.__sprite.get_rect()
class Attack_horizontal:
    def __init__(self,player,color,direction,speed,pos,pos2,len):
        self.player=player
        self.colour = color
        if self.colour=='WHITE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51.png").convert_alpha(),
                (60, len))
        elif self.colour=='BLUE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51 (1).png").convert_alpha(),
                (60, len))
        else:
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/diusvrtcclf51 (2).png").convert_alpha(),
                (60, len))
        self.bone_rect= self.bone_spr.get_rect()
        self.bone_rect.x=pos2
        self.bone_rect.y=pos
        self.dir=direction
        self.speed=speed
        self.pos_get=self.player.get_x
        self.lengh=len
    def atc(self,player):
        if player.collision.x<self.bone_rect.x+15 and player.collision.x>self.bone_rect.x-15:
            if player.collision.y<self.bone_rect.centery+self.lengh//2 and player.collision.y>self.bone_rect.centery-self.lengh//2:
                if self.colour=='BLUE':
                    if self.pos_get != self.player.get_x:
                        player.get_damage(2)
                elif self.colour == 'YELLOW':
                    if self.pos_get == self.player.get_x:
                            player.get_damage(2)
                else:
                    player.get_damage(2)
        self.bone_rect.x+=self.speed*self.dir
        self.pos_get = self.player.get_x
    def draw(self,screen):
        screen.blit(self.bone_spr,self.bone_rect)
class Gaster_blaster:
    def __init__(self, player, color, direction, speed, pos,pos2):
        self.player = player
        self.dir = direction
        self.colour = color
        self.i=0
        if self.colour=='BLUE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (2).png").convert_alpha(),
                (165, 220))
            self.battle_spr=pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (5).png").convert_alpha(),
                (110, 145))
        elif self.colour=='ORANGE':
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (1).png").convert_alpha(),
                (110, 145))
            self.battle_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (6).png").convert_alpha(),
                (110, 145))
        else:
            self.bone_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (3).png").convert_alpha(),
                (60, 160))
            self.battle_spr = pygame.transform.smoothscale(
                pygame.image.load("dustdust/pngegg (4).png").convert_alpha(),
                (60, 160))
        self.bone_rect = self.bone_spr.get_rect()
        self.bone_rect.x = pos2-speed*100
        self.bone_rect.y = pos
        self.speed = speed

    def atc(self, player):
        if 100<self.i<270:
            self.bone_spr=self.battle_spr
            if player.collision.x < self.bone_rect.x + 15 and player.collision.x > self.bone_rect.x - 15:
                if player.collision.y < self.bone_rect.centery + 80 and player.collision.y > self.bone_rect.centery - 80:
                    player.get_damage(5)
        elif self.i>270:
            if self.bone_rect.x>540:
                self.bone_rect.x+=100
            else:
                self.bone_rect.x -= 100
    def draw(self, screen):
        screen.blit(self.bone_spr, self.bone_rect)
        self.i += self.speed
        if self.i<100:
            self.bone_rect.x+=100/self.speed
        if 100 < self.i < 270:
            self.randomiser=random.randint(-10,10)
            pygame.draw.rect(screen, [140, 140, 140],
                             pygame.Rect(self.bone_rect.x + (90-50-self.randomiser)//2, self.bone_rect.y + 120, 70-self.randomiser, 500))
            pygame.draw.rect(screen, [200, 200, 200],
                             pygame.Rect(self.bone_rect.x + (90-60-self.randomiser)//2, self.bone_rect.y + 120, 60-self.randomiser, 500))
            pygame.draw.rect(screen, [255, 255, 255],
                             pygame.Rect(self.bone_rect.x +  (90-50-self.randomiser)//2, self.bone_rect.y + 120, 50-self.randomiser, 500))
class Fight:
    def __init__(self,screen_width, screen_height,player):
        self.width=screen_width
        self.height=screen_height
        self.player=player
        self.hp=100
        self.w=252
        self.ans=True
        self.h = 408
        self.countdown = 0
        self.g = 0
        self.r=False
        self.attacks=[]
        self.boots=[self.width//3,30]
        self.hoodie=[self.width//3,30]
        self.head=[self.width//3,30]
        self.shorts=[self.width//3,30]
        self.legs=[self.width//3,30]
        self.font = pygame.font.Font("dustdust/impact.ttf", 24)
        self.status=False
        self.talk = self.font.render('', True,
                             (255, 255, 255))
        self.k=10
        self.j=0
        self.head_coord=[10,0]
        self.talk_coords=[0,0]
        self.frame_cnt=0
        self.button_sprites2 = [
            pygame.transform.smoothscale(pygame.image.load("dustdust/fightcl.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Actcl.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/ITEMCL.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Mercycl.png").convert_alpha(), (138, 50))]
        self.button_sprites=[pygame.transform.smoothscale(pygame.image.load("dustdust/fight.png").convert_alpha(),(138,50)),
                             pygame.transform.smoothscale(pygame.image.load("dustdust/Act.png").convert_alpha(),(138,50)),
                             pygame.transform.smoothscale(pygame.image.load("dustdust/ITEM.png").convert_alpha(),(138,50)),
                             pygame.transform.smoothscale(pygame.image.load("dustdust/Mercy.png").convert_alpha(),(138,50))]
        self.button_spritesr = [
            pygame.transform.smoothscale(pygame.image.load("dustdust/fight.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Act.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/ITEM.png").convert_alpha(), (138, 50)),
            pygame.transform.smoothscale(pygame.image.load("dustdust/Mercy.png").convert_alpha(), (138, 50))]
        self.coords_buttons = [[500-60,800],[610,800],[810-30,800],[1010-60,800]]
        self.coords=[self.boots, self.hoodie,self.head,self.shorts,self.legs,[self.width//3-10,30-10]]
        self.__sprites = [pygame.transform.smoothscale(pygame.image.load("dustdust/boots.png").convert_alpha(),(self.w,int(self.h ))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/hoodie.png").convert_alpha(),(self.w,int(self.h ))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/head.png").convert_alpha(),(self.w,int(self.h ))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/shorts.png").convert_alpha(),(self.w,int(self.h ))),
                          pygame.transform.smoothscale(pygame.image.load("dustdust/legs.png").convert_alpha(),(self.w,int(self.h )))]

    def fight(self):
        self.player.boundaries_x=[500, self.width//2]
        self.player.boundaries_y = [self.height//2-90, self.height//1.5]

    def rot(self,image, angle):
        return image+angle
    def anim(self):
        self.frame_cnt += 1
        if self.frame_cnt%3==0:
            if self.k>0:
                self.coords[1][1]+=(11-self.k)/10
                self.coords[2][1] += (12 - self.k) / 10
                self.coords[3][1] += (12 - self.k) / 10
                self.coords[4][1] += (12 - self.k) / 12
                self.k -= 1
            elif self.j>0:
                self.coords[1][1]-=(11-self.j)/10
                self.coords[2][1] -= (12 - self.j) / 10
                self.coords[3][1] -= (12 - self.j) / 10
                self.coords[4][1] -= (12 - self.j) / 12
                self.j-=1
            if self.k<1 and self.j<1 and self.frame_cnt%9==0:
                if self.coords[1][1]<30:
                    self.k=10
                else:
                    self.j=10
    def draw(self,screen):
        pygame.draw.rect(screen, (0, 0, 0),
                         (500, self.height // 2 // 1.2,self.width//3-150, 310))
        pygame.draw.rect(screen, (255, 255, 255),
                         (500, self.height//2//1.2, self.width//3-150,310 ), 3)
        self.count=0
        screen.blit(self.__sprites[4],self.coords[4])
        screen.blit(self.__sprites[3], self.coords[3])
        screen.blit(self.__sprites[1], self.coords[1])
        screen.blit(self.__sprites[2], self.coords[2])
        screen.blit(self.__sprites[0], self.coords[0])
        for i in range(len(self.button_sprites)):
            screen.blit(self.button_sprites[i], self.coords_buttons[i])

        self.finish_game(screen,self.player)
        self.frame_cnt += 1
        self.win(self.hp, screen)
        self.spare(self.status,screen)
        screen.blit(self.talk, (self.talk_coords))
        if self.player.hp>0 and self.hp>0:
            self.countdown -=1
            if self.countdown<1:
                self.talk = self.font.render('', True,
                                     (255, 255, 255))
    def finish_game(self,screen,player):
        if player.hp<1:
            screen.fill([0,0,0])
            j = pygame.font.Font(None, 48)
            self.talk = j.render('ВЫ ПРОИГРАЛИ', True,
                                 (255, 255, 255))
            self.talk_coords = [670,450]
    def spare(self,status, screen):
        if status==True:
            screen.fill([0,0,0])
            j = pygame.font.Font(None, 48)
            self.talk = j.render('ВЫ ЗАКОНЧИЛИ БОЙ МИРНО', True,
                                 (255, 255, 255))
            self.talk_coords = [550,450]
            self.hp=0
    def choosing_button(self,event,bl,atclist):
        if self.ans==False:
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_a and self.g>0:
                    self.g-=1
                elif event.key==pygame.K_d and self.g<3:
                    self.g+=1
                if self.g!=-1:
                    self.button_sprites[self.g]=self.button_sprites2[self.g]
                for i in range(4):
                    if i!=self.g:
                        self.button_sprites[i]=self.button_spritesr[i]
                self.player.change_pos(self.coords_buttons[self.g][0],self.coords_buttons[self.g][1])
            if event.type==pygame.MOUSEBUTTONDOWN:
                if self.g==0:
                    self.hp-=25
                    j = pygame.font.Font(None, 24)
                    text=str(self.hp)+'/100'
                    self.talk = j.render(text, True,
                                         (255, 255, 255))
                    self.talk_coords = [550, 500]
                elif self.g==1:
                    j = pygame.font.Font(None, 24)
                    self.talk = j.render('Разговоры не помогут', True,
                                 (255, 255, 255))
                    self.talk_coords = [550, 500]
                elif self.g==2:
                    self.player.get_damage(-10)
                else:
                    self.status=True
                    self.talk_coords=[550,500]
                self.button_sprites[self.g] = self.button_spritesr[self.g]
                self.ans=True
                self.countdown=30
    def win(self,hp,screen):
        if hp<1:
            screen.fill([0,0,0])
            j = pygame.font.Font(None, 48)
            self.talk = j.render('ВЫ ПОБЕДИЛИ', True,
                                 (255, 255, 255))
            self.talk_coords = [670,450]
class Game:
    def __init__(self, width=1920, height=1080, fps=60,hp=20,dmg1=10,dmg=10):
        pygame.init()
        self.__cnt=1
        self.__STATUS = [1,1]
        self.__hp= hp
        self.__dmg1=dmg1
        self.__dmg=dmg
        self.__width = width
        self.__height = height
        self.__K=[]
        self.__width2 = width
        self.__height2 = height
        self.__hp2 = hp
        self.__screen = pygame.display.set_mode((self.__width, self.__height),pygame.FULLSCREEN)
        self.__bg_sprite = pygame.transform.smoothscale(
            pygame.image.load("sprites/bg.jpg").convert(),
            (1920, 1080)
        )
        self.__x = 800 // 2 - 60
        self.__y = 600 // 2 - 60
        self.t = random.randint(1, 5)
        self.__fps = fps
        self.__clock = pygame.time.Clock()
        self.__game_end = False
        self.__s=[]
        self.__player = Player(self.__width, self.__height,self.__hp,self.__dmg,self.__x,self.__y)
        self.__fight=Fight(self.__width, self.__height,self.__player)
        self.actions =self.__fight.ans
        self.attacks_list=[[],[],[]]
        self.attacks()
        self.i=0
        self.frame_count=0
        self.g=True
        self.activat=False
    def __del__(self):
        pygame.quit()
    def run(self):
        while not self.__game_end:
            self.__check_events()
            self.__check_logic()
            self.__move_objects()
            self.__draw()
            self.__flip()
            self.__clock.tick(self.__fps)
    def __check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.__game_end = True

            self.__player.check_event(event)
            self.__fight.choosing_button(event,self.actions,self.attacks_list)
    def __check_logic(self):
        self.__player.check_logic()

    def __move_objects(self):
        self.__player.move()
    def __draw(self):
        self.actions = self.__fight.ans
        self.__screen.blit(self.__bg_sprite, (0, 0))
        if self.g==True:
            if self.activat==False:
                self.__bg_sprite = pygame.transform.smoothscale(
                    pygame.image.load("dustdust/bc.png").convert(),
                    (1600, 890))
                self.activat=True
            self.__fight.anim()
            self.__fight.draw(self.__screen)
            if self.actions and self.__player.hp>0 and self.__fight.hp>0:
                self.battle()
        if self.__player.hp > 0 and self.__fight.hp > 0:
            self.__player.draw(self.__screen)
    def __flip(self):
        pygame.display.flip()
    def __fighting(self):
        self.__fight.fight()
    def battle(self):
        print(self.frame_count)
        if len(self.attacks_list)>0:
            if self.i<len(self.attacks_list[0])*30:
                self.i+=1
            self.frame_count=self.i//30
            for i in self.attacks_list[0][0:self.frame_count]:
                if i!='':
                    if str(type(i))!="<class 'list'>" and str(type(i))!="<class 'bool'>":
                        i.draw(self.__screen)
                        i.atc(self.__player)
                    elif str(type(i))=="<class 'bool'>":
                        self.actions=False
                        self.__fight.ans=False
                        self.i=0
                        self.attacks_list.pop(0)
                        self.frame_count=0
                    else:
                        for j in i:
                            j.draw(self.__screen)
                            j.atc(self.__player)
            self.__fighting()
    def attacks(self,b=[]):
        b=[]
        b.append(Attack_horizontal(self.__player,'WHITE',1,4,450,400,160))
        b.append(Attack_horizontal(self.__player,'WHITE',-1,4,600,1200,160))
        for i in range(10):
            self.attacks_list[0].append([Attack_horizontal(self.__player,'WHITE',1,5,450,400,160),Attack_horizontal(self.__player,'WHITE',-1,5,600,1300,160)])
        b=[(Attack_horizontal(self.__player,'WHITE',1,10,450,400,100)),
           (Attack_horizontal(self.__player,'WHITE',1,10,650,400,100)),
           (Attack_horizontal(self.__player,'WHITE',-1,10,650,1200,100)),
           (Attack_horizontal(self.__player,'WHITE',-1,10,450,1200,100))]

        self.attacks_list[0].append(b)
        for i in range(3):
            self.attacks_list[0].append([Attack_horizontal(self.__player,'BLUE',-1,9,350,1200,240),Attack_horizontal(self.__player,'BLUE',-1,10,600,1300,500)])
            self.attacks_list[0].append([Attack_horizontal(self.__player, 'BLUE', -1, 6, 500, 1200,160),
                                      Attack_horizontal(self.__player, 'YELLOW', -1, 6, 600, 1300,190)])
            self.attacks_list[0].append([Attack_horizontal(self.__player, 'BLUE', -1, 9, 450, 1200,200),
                                      Attack_horizontal(self.__player, 'BLUE', -1, 11, 700, 1300,170),Attack_horizontal(self.__player, 'WHITE', -1, 5, 600, 1300, 160)])
            self.attacks_list[0].append([Attack_horizontal(self.__player, 'YELLOW', -1, 6, 450, 1200, 200),
                                     Attack_horizontal(self.__player, 'BLUE', -1, 3, 400, 1300, 170),Attack_horizontal(self.__player, 'WHITE', 1, 5, 450, 400, 160)])
        self.attacks_list[0].append(False)
        for i in range(3):
            self.attacks_list[1].append([Attack_horizontal(self.__player, 'BLUE', 1, 10, 400, 400, 400),
                                          Attack_horizontal(self.__player, 'YELLOW', -1, 10, 400, 1300, 400)])
            self.attacks_list[1].append('')
        self.attacks_list[1].append(False)
        for i in range(10):
            self.attacks_list[2].append(Attack_horizontal(self.__player, 'WHITE', 1, 4, 450, 400, 240))
            self.attacks_list[2].append([Attack_horizontal(self.__player, 'BLUE', 1, 10, 680, 300, 80),
                                         Attack_horizontal(self.__player, 'YELLOW', 1, 10, 680, 400, 80)])
        self.attacks_list[2].append(False)
        b=self.attacks_list[0][::]
        for i in range(10):
            self.attacks_list.append(b)



def main():
    game = Game()
    game.run()


if __name__ == "__main__":
    main()
